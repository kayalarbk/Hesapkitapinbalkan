# Ikonlari yeniden uretir:  pip install pillow && python3 tools/make-icons.py
from PIL import Image, ImageDraw
import os

INK   = (14, 32, 39)
TRACK = (32, 58, 68)
EUR   = (233, 166, 60)
MKD   = (62, 157, 178)
ALL_  = (127, 194, 155)

def ring(size, pad_ratio, bg=True, radius_ratio=0.30, width_ratio=0.115):
    S = size * 4  # supersample
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if bg:
        d.rounded_rectangle([0, 0, S, S], radius=int(S * 0.22), fill=INK)
    cx = cy = S / 2
    r = S * radius_ratio
    w = int(S * width_ratio)
    box = [cx - r, cy - r, cx + r, cy + r]
    d.arc(box, 0, 360, fill=TRACK, width=w)
    # three arcs: 44% EUR, 26% MKD, 15% ALL -> leaves a gap = remaining budget
    start = -90
    for frac, col in ((0.44, EUR), (0.26, MKD), (0.15, ALL_)):
        end = start + frac * 360
        d.arc(box, start, end, fill=col, width=w)
        start = end
    return img.resize((size, size), Image.LANCZOS)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "icons")
os.makedirs(OUT, exist_ok=True)

# standard icons (with background)
for s in (192, 512):
    ring(s, 0).save(os.path.join(OUT, f"icon-{s}.png"))

# maskable: same but ring smaller so it survives the safe-zone crop
ring(512, 0, radius_ratio=0.235, width_ratio=0.09).save(os.path.join(OUT, "icon-maskable-512.png"))

# apple touch icon (no transparency, square corners handled by iOS)
img = Image.new("RGB", (180, 180), INK)
img.paste(ring(180, 0).convert("RGB"), (0, 0))
img.save(os.path.join(OUT, "apple-touch-icon.png"))

print("yazildi:", sorted(os.listdir(OUT)))
