# Balkan Hesap Defteri — v1.1.0

Balkan yolculuğu için çok para birimli harcama defteri. Vanilla HTML/CSS/JS, build adımı yok, dış bağımlılık yok, tamamen çevrimdışı çalışır.

## Dosyalar

```
index.html               tek dosyalık uygulama (HTML + CSS + JS)
manifest.webmanifest     PWA manifesti
sw.js                    service worker (CACHE_VERSION ile sürümlenir)
icons/                   192 / 512 / maskable / apple-touch ikonları
tools/make-icons.py      ikonları yeniden üreten betik
```

## v1.1'de yeni

- Harcamalara **saat** kaydı; gün içi liste saate göre sıralı
- **Düzenleme**: harcama veya bozdurma kalemine dokun, form dolsun, "Değişikliği kaydet"
- **20 hazır kategori** + Ayarlar'dan kendi kategorini ekleme/silme
- **Açık / Koyu / Sistem** tema seçimi
- Eski sürüm yedekleri sorunsuz yüklenir (saati olmayan kayıtlara 12:00 atanır, bilinmeyen kategoriler listeye eklenir)

## Yayına alma (GitHub Pages)

```bash
git init && git add . && git commit -m "Balkan hesap defteri v1.1"
git branch -M main
git remote add origin git@github.com:kayalarbk/<repo>.git
git push -u origin main
```

Repo → Settings → Pages → Source: `main` / root. Adres `https://kayalarbk.github.io/<repo>/`.

**HTTPS şart** — service worker yalnızca https veya localhost'ta çalışır.

## Telefona kurma

- **Android / Chrome:** siteyi aç → Ayarlar sekmesindeki "Ana ekrana ekle" veya tarayıcı menüsü.
- **iOS / Safari:** Paylaş → "Ana Ekrana Ekle". iOS'ta `beforeinstallprompt` yok, düğme görünmez.

## Güncelleme

`index.html`'i değiştirdikten sonra **`sw.js` içindeki `CACHE_VERSION`'ı artır** (`balkan-v2` → `balkan-v3`), sonra commit + push. Aksi halde telefon eski önbelleği göstermeye devam eder.

## Uygulama simgesini değiştirme

Simge üç dosyadan geliyor: `icons/icon-192.png`, `icons/icon-512.png`, `icons/icon-maskable-512.png` (bir de iOS için `icons/apple-touch-icon.png`).

**Yol 1 — kendi görselin.** Kare bir PNG hazırla, dört boyutta dışa aktar (192, 512, 512 maskable, 180 apple-touch), aynı isimlerle `icons/` içine koy, üzerine yaz. Maskable olanda tasarımı merkeze topla: Android ikonu daire/squircle olarak kırpıyor, kenardaki her şey gider. Güvenli alan, kenarın **%10'unu boş bırakmak**.

**Yol 2 — betikle üret.** `tools/make-icons.py` mevcut halka simgesini çiziyor. Renkleri ya da oranları değiştirip çalıştır:

```bash
pip install pillow
python3 tools/make-icons.py
```

Dosyayı açtığında en üstteki `INK`, `EUR`, `MKD`, `ALL_` RGB değerleri simgenin renkleri; alttaki `((0.44, EUR), (0.26, MKD), (0.15, ALL_))` üçlüsü halkanın dilim oranları.

**Değiştirdikten sonra üç şey gerekli:**
1. `sw.js` içindeki `CACHE_VERSION`'ı artır — eski ikon önbellekte duruyor
2. commit + push
3. Telefonda uygulamayı ana ekrandan **kaldırıp yeniden ekle** — Android ve iOS kurulu ikonu değiştirmez, kurulum anındaki görseli saklar

Manifest'i sadece dosya adlarını ya da boyutları değiştirirsen elle güncellemen gerekir.

## Veri

Her şey `localStorage`'da, `balkan-ledger-v1` anahtarında. Sunucu yok, hesap yok, senkron yok. Ayarlar → Veri → **Yedek al** ile JSON iner, aynı yerden geri yüklenir. Tarayıcı verisini temizlersen kayıtlar gider.

## Mantık notları

- **Bütçe** = yanına aldığın nakit euro. Kartla ödenenler ayrı toplanır, bakiyeden düşmez.
- **Kur**: bir para birimi için bozdurma girildiği anda o birimdeki tüm harcamalar gerçek ortalama kurdan euroya çevrilir. Bozdurma yoksa Ayarlar'daki tahmini kur kullanılır.
- **Cepte kalan** = bozdurulan miktar − o birimdeki nakit harcama. Euro için: bütçe − bozdurmaya verilen euro − nakit euro harcama.
- Lira kuru yalnızca kıyas amaçlı; bütçe hesabına girmez.
